<template>
    <div>
        <h1>Seasdrch</h1>
    </div>
</template>

<script>

</script>

<style lang="scss" scoped>

</style>