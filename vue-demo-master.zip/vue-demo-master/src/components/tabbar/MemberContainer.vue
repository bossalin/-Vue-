<template>
    <div>
        <h2>Member</h2>
    </div>
</template>

<script>

</script>

<style lang="scss" scoped>

</style>